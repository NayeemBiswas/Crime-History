package PoliceCrime;
public class address {
    String add_id;
    String line;
    String postcode;
    String city;
    String country;

    public address(String add_id, String line, String postcode, String city, String country) {
        this.add_id = add_id;
        this.line = line;
        this.postcode = postcode;
        this.city = city;
        this.country = country;
    }

    public String getAdd_id() {
        return add_id;
    }

    public String getLine() {
        return line;
    }

    public String getPostcode() {
        return postcode;
    }

    public String getCity() {
        return city;
    }

    public String getCountry() {
        return country;
    }

    public void setAdd_id(String add_id) {
        this.add_id = add_id;
    }

    public void setLine(String line) {
        this.line = line;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setCountry(String country) {
        this.country = country;
    }
    
}
