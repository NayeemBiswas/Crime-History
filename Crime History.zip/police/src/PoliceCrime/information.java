package PoliceCrime;
public class information {
    String info_id;
    String person_id;
    String vehi_reg_no;
    String loc_id;
    String crime_catagory;
    String add_id;
    String crime_activities;
    String reported_by;
    Object getCrime_activities;

    public information(String info_id, String person_id, String vehi_reg_no, String loc_id, String crime_catagory, String add_id, String crime_activities, String reported_by) {
        this.info_id = info_id;
        this.person_id = person_id;
        this.vehi_reg_no = vehi_reg_no;
        this.loc_id = loc_id;
        this.crime_catagory = crime_catagory;
        this.add_id = add_id;
        this.crime_activities = crime_activities;
        this.reported_by = reported_by;
    }

    public void setInfo_id(String info_id) {
        this.info_id = info_id;
    }

    public void setPerson_id(String person_id) {
        this.person_id = person_id;
    }

    public void setVehi_reg_no(String vehi_reg_no) {
        this.vehi_reg_no = vehi_reg_no;
    }

    public void setLoc_id(String loc_id) {
        this.loc_id = loc_id;
    }

    public void setCrime_catagory(String crime_catagory) {
        this.crime_catagory = crime_catagory;
    }

    public void setAdd_id(String add_id) {
        this.add_id = add_id;
    }

    public void setCrime_activities(String crime_activities) {
        this.crime_activities = crime_activities;
    }

    public void setReported_by(String reported_by) {
        this.reported_by = reported_by;
    }

    public String getInfo_id() {
        return info_id;
    }

    public String getPerson_id() {
        return person_id;
    }

    public String getVehi_reg_no() {
        return vehi_reg_no;
    }

    public String getLoc_id() {
        return loc_id;
    }

    public String getCrime_catagory() {
        return crime_catagory;
    }

    public String getAdd_id() {
        return add_id;
    }

    public String getCrime_activities() {
        return crime_activities;
    }

    public String getReported_by() {
        return reported_by;
    }
    
}
