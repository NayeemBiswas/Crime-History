package PoliceCrime;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Databasehandeler {

    Connection conn = null;
    ResultSet rs = null;
    PreparedStatement pst = null;

    public Databasehandeler() {

        try {
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection("jdbc:sqlite:E:\\project\\Police.sqlite");
        } catch (ClassNotFoundException | SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, "Something went wrong");
        }

    }

    public void insertintolocation(locatio location) {
        try {
            String quiry = "insert into location values(?,?,?)";
            pst = conn.prepareStatement(quiry);
            pst.setString(1, location.getLoc_id());
            pst.setString(2, location.getLoc_summary());
            pst.setString(3, location.getDecribtion());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Your record has been saved!");
        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, "Something went worng!");

        }
    }

    public void updateintlocation(String id, locatio location) {
        String add_id = (id);
        try {
            String sql = "update location set loc_id='" + location.getLoc_id() + "',loc_summary ='" + location.getLoc_summary() + "',describtion ='" + location.getDecribtion() + "' where loc_id='" + id + "'";
            pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Successfully update");
            conn.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

    }

    public void deletelocation(String id) {

        try {
            String sql = "delete from location where loc_id='" + id + "'";
            pst = conn.prepareStatement(sql);
            pst.execute();

            JOptionPane.showMessageDialog(null, "Successfully Deleted");
            conn.close();

        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public ArrayList<locatio> getAll_location() throws SQLException {
        ArrayList<locatio> vehicles_list = new ArrayList<>();

        String query = "select * from location";
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            locatio vehiclesJFrame = new locatio("abs", "qw", "df");

            vehiclesJFrame.setLoc_id(rs.getString(1));
            vehiclesJFrame.setLoc_summary(rs.getString(2));
            vehiclesJFrame.setDecribtion(rs.getString(3));
            vehicles_list.add(vehiclesJFrame);

        }

        return vehicles_list;
    }

    public void insertintovehicles(vehicles vehicles) {
        try {
            String quiry = "insert into vehicles values(?,?,?)";
            pst = conn.prepareStatement(quiry);
            pst.setString(1, vehicles.getVehi_reg_no());
            pst.setString(2, vehicles.getColor());
            pst.setString(3, vehicles.getDetails());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Your record has been saved!");
        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, "Something went worng!");

        }
    }

    public void updateintvehicles(String id, vehicles vehicles) {
        String vehi_reg_no = (id);
        try {
            String sql = "update vehicles set vehi_reg_no ='" + vehicles.getVehi_reg_no() + "',details  ='" + vehicles.getColor() + "',color  ='" + vehicles.getDetails() + "' where vehi_reg_no ='" + id + "'";
            pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Successfully update");
            conn.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

    }

    public void deletevehi(String id) {

        try {
            String sql = "delete from vehicles where vehi_reg_no='" + id + "'";
            pst = conn.prepareStatement(sql);
            pst.execute();

            JOptionPane.showMessageDialog(null, "Successfully Deleted");
            conn.close();

        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public ArrayList<vehicles> getAll_vehicles() throws SQLException {
        ArrayList<vehicles> vehicles_list = new ArrayList<>();

        String query = "select * from vehicles";
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            vehicles vehiclesJFrame = new vehicles("abs", "qw", "df");

            vehiclesJFrame.setVehi_reg_no(rs.getString(1));
            vehiclesJFrame.setColor(rs.getString(2));
            vehiclesJFrame.setDetails(rs.getString(3));
            vehicles_list.add(vehiclesJFrame);

        }

        return vehicles_list;
    }

    public void insertintoaddress(address address) {
        try {
            String quiry = "insert into address values(?,?,?,?,?)";
            pst = conn.prepareStatement(quiry);
            pst.setString(1, address.getAdd_id());
            pst.setString(2, address.getLine());
            pst.setString(3, address.getCity());
            pst.setString(4, address.getPostcode());
            pst.setString(5, address.getCountry());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Your record has been saved!");
        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, "Something went worng!");

        }
    }

    public void updateintaddress(String id, address address) {
        String add_id = (id);
        try {
            String sql = "update address set add_id='" + address.getAdd_id() + "',line_1='" + address.getLine() + "',city='" + address.getCity() + "',postcode='" + address.getPostcode() + "',country='" + address.getCountry() + "' where add_id='" + id + "'";
            pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Successfully update");
            conn.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

    }

    public void deleteaddress(String id) {

        try {
            String sql = "delete from address where add_id='" + id + "'";
            pst = conn.prepareStatement(sql);
            pst.execute();

            JOptionPane.showMessageDialog(null, "Successfully Deleted");
            conn.close();

        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public ArrayList<address> getAll_address() throws SQLException {
        ArrayList<address> address_list = new ArrayList<>();

        String query = "select * from address";
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            address vehiclesJFrame = new address("abs", "qw", "df", "qw", "df");

            vehiclesJFrame.setAdd_id(rs.getString(1));
            vehiclesJFrame.setLine(rs.getString(2));
            vehiclesJFrame.setPostcode(rs.getString(3));
            vehiclesJFrame.setCity(rs.getString(4));
            vehiclesJFrame.setCountry(rs.getString(5));
            address_list.add(vehiclesJFrame);

        }

        return address_list;
    }

    public void insertintoperson(person person) {
        try {
            String quiry = "insert into person values(?,?,?,?)";
            pst = conn.prepareStatement(quiry);
            pst.setString(1, person.getPerson_id());
            pst.setString(2, person.getPerson_name());
            pst.setString(3, person.getGender());
            pst.setString(4, person.getD_O_B());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Your record has been saved!");
        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, "Something went worng!");

        }
    }

    public void updateintperson(String id, person person) {
        String person_id = (id);
        try {
            String sql = "update person set person_id='" + person.getPerson_id() + "',person_name='" + person.getPerson_name() + "',gender='" + person.getGender() + "',B_O_B='" + person.getD_O_B() + "' where person_id='" + id + "'";
            pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Successfully update");
            conn.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

    }
    
    
    public void deleteperson(String id) {

        try {
            String sql = "delete from person where person_id='" + id + "'";
            pst = conn.prepareStatement(sql);
            pst.execute();

            JOptionPane.showMessageDialog(null, "Successfully Deleted");
            conn.close();

        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    
    
          public ArrayList<person> getAll_person() throws SQLException {
        ArrayList<person> person_list = new ArrayList<>();

        String query = "select * from person";
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            person vehiclesJFrame = new person("abs", "qw","abs", "qw");

            vehiclesJFrame.setPerson_id(rs.getString(1));
            vehiclesJFrame.setPerson_name(rs.getString(2));
            vehiclesJFrame.setGender(rs.getString(3));
            vehiclesJFrame.setD_O_B(rs.getString(4));
            
            person_list.add(vehiclesJFrame);

        }

        return person_list;
    }
    
    
    
    

    public void insertintocatagori(catagori catagories) {
        try {
            String quiry = "insert into catagories values(?,?)";
            pst = conn.prepareStatement(quiry);
            pst.setString(1, catagories.getCrime_cat());
            pst.setString(2, catagories.getDetails());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Your record has been saved!");
        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, "Something went worng!");

        }
    }

    
    
    
    public void updateintocatagori(String id, catagori catagories) {
        String crime_catagory = (id);
        try {
            String sql = "update catagories set crime_catagory='" + catagories.getCrime_cat() + "',discribtion='" + catagories.getDetails() + "' where crime_catagory='" + id + "'";
            pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Successfully update");
            conn.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

    }

    public void deletecat(String id) {

        try {
            String sql = "delete from catagories where crime_catagory='" + id + "'";
            pst = conn.prepareStatement(sql);
            pst.execute();

            JOptionPane.showMessageDialog(null, "Successfully Deleted");
            conn.close();

        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    
      public ArrayList<catagori> getAll_cat() throws SQLException {
        ArrayList<catagori> cat_list = new ArrayList<>();

        String query = "select * from catagories";
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            catagori vehiclesJFrame = new catagori("abs", "qw");

            vehiclesJFrame.setCrime_cat(rs.getString(1));
            vehiclesJFrame.setDetails(rs.getString(2));
            cat_list.add(vehiclesJFrame);

        }

        return cat_list;
    }
    
    

    public void insertintoinformation(information information) {
        try {
            String quiry = "insert into information values(?,?,?,?,?,?,?,?)";
            pst = conn.prepareStatement(quiry);
            pst.setString(1, information.getInfo_id());
            pst.setString(2, information.getPerson_id());
            pst.setString(3, information.getVehi_reg_no());
            pst.setString(4, information.getLoc_id());
            pst.setString(5, information.getCrime_catagory());
            pst.setString(6, information.getAdd_id());
            pst.setString(7, information.getCrime_activities());
            pst.setString(8, information.getReported_by());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Your record has been saved!");
        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, "Something went worng!");

        }
    }

    public void updateintinformation(String id, information information) {
        String user_id = id;
        try {
            String sql = "update information set information_id ='" + information.getInfo_id() + "',person_id ='" + information.getPerson_id() + "',vehi_reg_no ='" + information.getVehi_reg_no() + "',loc_id ='" + information.getLoc_id() + "',crime_catagory ='" + information.getCrime_catagory() + "',add_id ='" + information.getAdd_id() + "'," + "crime_activities ='" + information.getCrime_activities() + "',reported_by ='" + information.getReported_by() + "' where information_id='" + id + "'";
            pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Successfully update");
            conn.close();

        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, e);
        }

    }

    public void deleteinformation(String id) {

        try {
            String sql = "delete from information where information_id='" + id + "'";
            pst = conn.prepareStatement(sql);
            pst.execute();

            JOptionPane.showMessageDialog(null, "Successfully Deleted");
            conn.close();

        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    
        public ArrayList<information> getAll_information() throws SQLException {
        ArrayList<information> information_list = new ArrayList<>();

        String query = "select * from information";
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            information vehiclesJFrame = new information("abs", "qw", "df", "qw", "df", "df", "qw", "df");

            vehiclesJFrame.setInfo_id(rs.getString(1));
            vehiclesJFrame.setPerson_id(rs.getString(2));
            vehiclesJFrame.setVehi_reg_no(rs.getString(3));
            vehiclesJFrame.setLoc_id(rs.getString(4));
            vehiclesJFrame.setCrime_catagory(rs.getString(5));
            vehiclesJFrame.setAdd_id(rs.getString(6));
            vehiclesJFrame.setCrime_activities(rs.getString(7));
            vehiclesJFrame.setReported_by(rs.getString(8));
            information_list.add(vehiclesJFrame);

        }

        return information_list;
    }
    
}
