package PoliceCrime;
public class vehicles {
    String vehi_reg_no;
    String color;
    String details;

    public String getVehi_reg_no() {
        return vehi_reg_no;
    }

    public String getColor() {
        return color;
    }

    public String getDetails() {
        return details;
    }

    public void setVehi_reg_no(String vehi_reg_no) {
        this.vehi_reg_no = vehi_reg_no;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setDetails(String details) {
        this.details = details;
    }
    
    
    public vehicles(String vehi_reg_no, String color, String details) {
        this.vehi_reg_no = vehi_reg_no;
        this.color = color;
        this.details = details;
    }
}
