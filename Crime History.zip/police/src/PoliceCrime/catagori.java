/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PoliceCrime;

/**
 *
 * @author Nayeem
 */
public class catagori {
    String crime_cat;
    String details;

    public catagori(String crime_cat, String details) {
        this.crime_cat = crime_cat;
        this.details = details;
    }

    public void setCrime_cat(String crime_cat) {
        this.crime_cat = crime_cat;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getCrime_cat() {
        return crime_cat;
    }

    public String getDetails() {
        return details;
    }
    
}
