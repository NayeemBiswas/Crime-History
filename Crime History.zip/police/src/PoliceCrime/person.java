package PoliceCrime;
public class person {
    String person_id;
    String person_name;
    String gender;
    String d_O_B;

    public person(String person_id, String person_name, String gender, String d_O_B) {
        this.person_id = person_id;
        this.person_name = person_name;
        this.gender = gender;
        this.d_O_B = d_O_B;
    }


    public String getPerson_id() {
        return person_id;
    }

    public String getPerson_name() {
        return person_name;
    }

    public String getGender() {
        return gender;
    }

    public String getD_O_B() {
        return d_O_B;
    }

    public void setPerson_id(String person_id) {
        this.person_id = person_id;
    }

    public void setPerson_name(String person_name) {
        this.person_name = person_name;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setD_O_B(String d_O_B) {
        this.d_O_B = d_O_B;
    }
    
}
