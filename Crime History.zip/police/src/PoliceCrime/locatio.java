package PoliceCrime;
public class locatio {
    String loc_id;
    String loc_summary;
    String decribtion;

    public String getLoc_id() {
        return loc_id;
    }

    public String getLoc_summary() {
        return loc_summary;
    }

    public String getDecribtion() {
        return decribtion;
    }

    public void setLoc_id(String loc_id) {
        this.loc_id = loc_id;
    }

    public void setLoc_summary(String loc_summary) {
        this.loc_summary = loc_summary;
    }

    public void setDecribtion(String decribtion) {
        this.decribtion = decribtion;
    }
    
    public locatio(String loc_id, String loc_summary, String decribtion) {
        this.loc_id = loc_id;
        this.loc_summary = loc_summary;
        this.decribtion = decribtion;
    }
}